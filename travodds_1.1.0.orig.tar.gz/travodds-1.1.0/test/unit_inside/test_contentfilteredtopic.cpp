#include "gtest/gtest.h"
#include "dcps/domain/domainparticipantfactory.h"
#include "dcps/domain/domainparticipant.h"
#include "dcps/condition/waitset.h"
#include "testdataTypeSupport.h"
USING_TRAVODDS_NAMESPACE

TEST(ContentFilteredTopicTest, ContentFilteredTopic_get_filter_expression) {
    DomainParticipant* par = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, 0);
    const char* type_name = TestModule::BasicDataTypeSupport::get_instance()->get_typename();
    par->registe_type(type_name, TestModule::BasicDataTypeSupport::get_instance());
    Topic* top = par->create_topic("topicname", type_name, TOPIC_QOS_DEFAULT, nullptr, 0);
    std::string filter_expression = "id = 10 AND name = 'abc'";
	StringSeq expression_parameters;
    ContentFilteredTopic* cftop = par->create_contentfilteredtopic("cftop", top, filter_expression, expression_parameters);
    EXPECT_NE(cftop, nullptr);
    std::string result = cftop->get_filter_expression();
    EXPECT_EQ(result, filter_expression);
    par->delete_contained_entities();
    TheParticipantFactory->delete_participant(par);
}

TEST(ContentFilteredTopicTest, ContentFilteredTopic_get_related_topic) {
    DomainParticipant* par = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, 0);
    const char* type_name = TestModule::BasicDataTypeSupport::get_instance()->get_typename();
    par->registe_type(type_name, TestModule::BasicDataTypeSupport::get_instance());
    Topic* top = par->create_topic("topicname", type_name, TOPIC_QOS_DEFAULT, nullptr, 0);
    std::string filter_expression = "id = 10 AND name = 'abc'";
    StringSeq expression_parameters;
    ContentFilteredTopic* cftop = par->create_contentfilteredtopic("cftop", top, filter_expression, expression_parameters);
    Topic* result = cftop->get_related_topic();
    EXPECT_EQ(result, top);
    par->delete_contained_entities();
    TheParticipantFactory->delete_participant(par);
}

TEST(ContentFilteredTopicTest, ContentFilteredTopic_get_expression_parameters) {
    DomainParticipant* par = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, 0);
    const char* type_name = TestModule::BasicDataTypeSupport::get_instance()->get_typename();
    par->registe_type(type_name, TestModule::BasicDataTypeSupport::get_instance());
    Topic* top = par->create_topic("topicname", type_name, TOPIC_QOS_DEFAULT, nullptr, 0);
    std::string filter_expression = "id = %0 AND name = 'abc'";
    StringSeq expression_parameters;
	expression_parameters.push_back("10");
    ContentFilteredTopic* cftop = par->create_contentfilteredtopic("cftop", top, filter_expression, expression_parameters);
    StringSeq seqGet;
    ReturnCode_t result = cftop->get_expression_parameters(seqGet);
    EXPECT_EQ(result, RETCODE_OK);
    EXPECT_EQ(seqGet, expression_parameters);
    par->delete_contained_entities();
    TheParticipantFactory->delete_participant(par);
}

TEST(ContentFilteredTopicTest, ContentFilteredTopic_set_get_expression_parameters) {
    const char* type_name = TestModule::BasicDataTypeSupport::get_instance()->get_typename();

    DomainParticipant* par_w = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_w->registe_type(type_name, TestModule::BasicDataTypeSupport::get_instance());

    Topic* top_w = par_w->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    DataWriter* dw = par_w->create_publisher(PUBLISHER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datawriter(top_w, DATAWRITER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);

    DomainParticipant* par_r = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_r->registe_type(type_name, TestModule::BasicDataTypeSupport::get_instance());
    Topic* top_r = par_r->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    std::string filter_expression = "id = %0 AND name = 'abc'";
    StringSeq expression_parameters = { "10" };
    ContentFilteredTopic* cftop = par_r->create_contentfilteredtopic("CFT_ContentFilteredTopic", top_r, filter_expression, expression_parameters);
    DataReader* dr = par_r->create_subscriber(SUBSCRIBER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datareader(cftop, DATAREADER_QOS_DEFAULT, nullptr, DATA_AVAILABLE_STATUS);

    StatusCondition& sc = dr->get_statuscondition();
    WaitSet ws;
    ws.attach_condition(sc);
    ConditionSeq active_conditions;
    std::thread th_1(
        [&] {
            EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_OK);

            SequenceData<TestModule::BasicData> data_seq;
            SampleInfoSeq info_seq;

            EXPECT_EQ(dr->take(
                data_seq, info_seq, LENGTH_UNLIMITED,
                ANY_SAMPLE_STATE, ANY_VIEW_STATE, ANY_INSTANCE_STATE),
                RETCODE_OK);
            EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_TIMEOUT);
        });
    std::thread th_2(
        [&] {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));

            TestModule::BasicData data;
            data.id = 10;
            data.name = "abc";
            EXPECT_EQ(dw->write(&data, HANDLE_NIL), RETCODE_OK);
            StringSeq parameters = { "20" };
            std::this_thread::sleep_for(std::chrono::seconds(1));
            EXPECT_EQ(cftop->set_expression_parameters(parameters), RETCODE_OK);
            std::this_thread::sleep_for(std::chrono::seconds(1));
            EXPECT_EQ(dw->write(&data, HANDLE_NIL), RETCODE_OK);

        });
    th_1.join();
    th_2.join();
    par_w->delete_contained_entities();
    par_r->delete_contained_entities();
    TheParticipantFactory->delete_participant(par_w);
    TheParticipantFactory->delete_participant(par_r);
}

TEST(ContentFilteredTopicTest, ContentFilteredTopic_fuctest1) {
    const char* type_name = TestModule::FilterableDataTypeSupport::get_instance()->get_typename();

    DomainParticipant* par_w = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_w->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());

    Topic* top_w = par_w->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    DataWriter* dw = par_w->create_publisher(PUBLISHER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datawriter(top_w, DATAWRITER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);

    DomainParticipant* par_r = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_r->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());
    Topic* top_r = par_r->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
	std::string filter_expression = "((shortField > %0 AND longField < %1) OR (floatField BETWEEN %2 AND %3))\
    AND(stringField LIKE %4 OR fixedStringField = %5)\
    AND(nestedField.nestedFlag = 1 OR structArray[0].nestedId = %6)\
    AND NOT(enumField = 'VALUE_E')";
	StringSeq expression_parameters;
	expression_parameters.push_back("10");
	expression_parameters.push_back("1000");
	expression_parameters.push_back("1.5");
	expression_parameters.push_back("5.5");
	expression_parameters.push_back("'test%'");
	expression_parameters.push_back("'fixedValue'");
	expression_parameters.push_back("42");
	ContentFilteredTopic* cftop = par_r->create_contentfilteredtopic("CFT_ContentFilteredTopic", top_r, filter_expression, expression_parameters);
    DataReader* dr = par_r->create_subscriber(SUBSCRIBER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datareader(cftop, DATAREADER_QOS_DEFAULT, nullptr, DATA_AVAILABLE_STATUS);

    std::vector<TestModule::FilterableData> datas;

    // ====== ����1����ȷ�����ݣ�Ӧ��ƥ��������� ======
    {
        TestModule::FilterableData data1;
        // ����1: shortField > 10 AND longField < 1000
        data1.shortField = 50;      // > 10
        data1.longField = 500;      // < 1000

        // ����2: floatField BETWEEN 1.5 AND 5.5
        data1.floatField = 3.0f;    // ��1.5-5.5֮��

        // ����3: stringField LIKE 'test%' OR fixedStringField = 'fixedValue'
        data1.stringField = "testData";        // ƥ�� 'test%'
        data1.fixedStringField = "otherValue"; // ��ƥ�䣬��stringFieldƥ��

        // ����4: nestedField.nestedFlag = TRUE OR structArray[0].nestedId = 42
        data1.nestedField.nestedFlag = true;   // ƥ�� TRUE
        data1.structArray[0].nestedId = 100;   // ��ƥ�䣬��nestedFlagƥ��

        // ����5: NOT(enumField = 'VALUE_E')
        data1.enumField = TestModule::VALUE_A; // ����VALUE_E

        datas.push_back(data1);
    }

    // ====== ����2����ȷ�����ݣ��Ӳ�ͬ·��ƥ��������� ======
    {
        TestModule::FilterableData data2;
        // ����1: shortField > 10 AND longField < 1000
        data2.shortField = 100;     // > 10
        data2.longField = 800;      // < 1000

        // ����2: floatField BETWEEN 1.5 AND 5.5
        data2.floatField = 2.0f;    // ��1.5-5.5֮��

        // ����3: stringField LIKE 'test%' OR fixedStringField = 'fixedValue'
        data2.stringField = "otherData";    // ��ƥ�� 'test%'
        data2.fixedStringField = "fixedValue"; // ƥ�� 'fixedValue'

        // ����4: nestedField.nestedFlag = TRUE OR structArray[0].nestedId = 42
        data2.nestedField.nestedFlag = false;  // ��ƥ��
        data2.structArray[0].nestedId = 42;    // ƥ�� 42

        // ����5: NOT(enumField = 'VALUE_E')
        data2.enumField = TestModule::VALUE_B; // ����VALUE_E

        datas.push_back(data2);
    }

    // ====== ����3���������� - floatField������BETWEEN���� ======
    {
        TestModule::FilterableData data3;
        // ����1: shortField > 10 AND longField < 1000
        data3.shortField = 5;      // > 10
        data3.longField = 1500;      // < 1000

        // ����2: floatField BETWEEN 1.5 AND 5.5
        data3.floatField = 0.6f;    // ���󣺲���1.5-5.5֮��

        // OR���ֿ������㣬��ANDҪ����������������
        data3.stringField = "testData";
        data3.fixedStringField = "fixedValue";
        data3.nestedField.nestedFlag = true;
        data3.structArray[0].nestedId = 42;
        data3.enumField = TestModule::VALUE_A;

        datas.push_back(data3);
    }

    // ====== ����4���������� - �ַ��������������� ======
    {
        TestModule::FilterableData data4;
        // ����1: shortField > 10 AND longField < 1000
        data4.shortField = 50;      // > 10
        data4.longField = 500;      // < 1000

        // ����2: floatField BETWEEN 1.5 AND 5.5
        data4.floatField = 3.0f;    // ��1.5-5.5֮��

        // ����3: stringField LIKE 'test%' OR fixedStringField = 'fixedValue'
        data4.stringField = "wrongData";        // ���󣺲���'test'��ͷ
        data4.fixedStringField = "wrongFixed";  // ���󣺲�����'fixedValue'

        // ������������Ҳû�ã���ΪANDҪ����������
        data4.nestedField.nestedFlag = true;
        data4.structArray[0].nestedId = 42;
        data4.enumField = TestModule::VALUE_A;

        datas.push_back(data4);
    }

    // ====== ����5���������� - ����4�ų� ======
    {
        TestModule::FilterableData data5;
        // ����1: shortField > 10 AND longField < 1000
        data5.shortField = 50;      // > 10
        data5.longField = 500;      // < 1000

        // ����2: floatField BETWEEN 1.5 AND 5.5
        data5.floatField = 3.0f;    // ��1.5-5.5֮��

        // ����3: stringField LIKE 'test%' OR fixedStringField = 'fixedValue'
        data5.stringField = "testData";        // ƥ��
        data5.fixedStringField = "fixedValue"; // ƥ��

        // ����4: nestedField.nestedFlag = TRUE OR structArray[0].nestedId = 42
        data5.nestedField.nestedFlag = false;   // ƥ��
        data5.structArray[0].nestedId = 43;    // ƥ��

        // ����5: NOT(enumField = 'VALUE_E')
        data5.enumField = TestModule::VALUE_A;

        datas.push_back(data5);
    }

    // ====== ����6���������� - enumFieldΪVALUE_E��NOT�ų� ======
    {
        TestModule::FilterableData data6;
        // ����1: shortField > 10 AND longField < 1000
        data6.shortField = 50;      // > 10
        data6.longField = 500;      // < 1000

        // ����2: floatField BETWEEN 1.5 AND 5.5
        data6.floatField = 3.0f;    // ��1.5-5.5֮��

        // ����3: stringField LIKE 'test%' OR fixedStringField = 'fixedValue'
        data6.stringField = "testData";        // ƥ��
        data6.fixedStringField = "fixedValue"; // ƥ��

        // ����4: nestedField.nestedFlag = TRUE OR structArray[0].nestedId = 42
        data6.nestedField.nestedFlag = true;   // ƥ��
        data6.structArray[0].nestedId = 42;    // ƥ��

        // ����5: NOT(enumField = 'VALUE_E')
        data6.enumField = TestModule::VALUE_E; // ���󣺵���VALUE_E��NOT�ų�

        datas.push_back(data6);
    }


    StatusCondition& sc = dr->get_statuscondition();
    WaitSet ws;
	ws.attach_condition(sc);
    ConditionSeq active_conditions;
    std::thread th_1(
        [&] {
            for (int i = 0; i < 2; i++) {
                EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_OK);

                SequenceData<TestModule::FilterableData> data_seq;
                SampleInfoSeq info_seq;

                EXPECT_EQ(dr->take(
                    data_seq, info_seq, LENGTH_UNLIMITED,
                    ANY_SAMPLE_STATE, ANY_VIEW_STATE, ANY_INSTANCE_STATE),
                    RETCODE_OK);
                EXPECT_TRUE(data_seq[0].shortField > 10);
                EXPECT_TRUE(data_seq[0].longField < 1000 ||
                    (data_seq[0].floatField >= 1.5f && data_seq[0].floatField <= 5.5f));
                EXPECT_TRUE(data_seq[0].stringField.find("test") == 0 ||
                    data_seq[0].fixedStringField == "fixedValue");
                EXPECT_TRUE(data_seq[0].nestedField.nestedFlag == true ||
                    data_seq[0].structArray[0].nestedId == 42);
                EXPECT_NE(data_seq[0].enumField, TestModule::VALUE_E);
            }
            EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_TIMEOUT);
        });
    std::thread th_2(
        [&] {
            std::this_thread::sleep_for(std::chrono::seconds(2));
            for (const auto& data : datas) {
                EXPECT_EQ(dw->write(&data, HANDLE_NIL), RETCODE_OK);
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
            }
        });
    th_1.join();
    th_2.join();
    par_w->delete_contained_entities();
    par_r->delete_contained_entities();
    TheParticipantFactory->delete_participant(par_w);
    TheParticipantFactory->delete_participant(par_r);
}


TEST(ContentFilteredTopicTest, ContentFilteredTopic_fuctest2) {
    const char* type_name = TestModule::FilterableDataTypeSupport::get_instance()->get_typename();

    DomainParticipant* par_w = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_w->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());

    Topic* top_w = par_w->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    DataWriter* dw = par_w->create_publisher(PUBLISHER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datawriter(top_w, DATAWRITER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);

    DomainParticipant* par_r = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_r->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());
    Topic* top_r = par_r->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    std::string filter_expression = "(longArray[0] > 10 OR doubleArray[0] < 0.0)\
    AND (matrix2x3[0][0] = 1 OR floatMatrix[1][1] > 0.5)\
    AND (structArray[0].nestedArray[0] > 0 AND structArray[1].nestedArray[1] < 100)";
    StringSeq expression_parameters;
    ContentFilteredTopic* cftop = par_r->create_contentfilteredtopic("CFT_ContentFilteredTopic", top_r, filter_expression, expression_parameters);
    DataReader* dr = par_r->create_subscriber(SUBSCRIBER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datareader(cftop, DATAREADER_QOS_DEFAULT, nullptr, DATA_AVAILABLE_STATUS);

    std::vector<TestModule::FilterableData> datas;
    // ====== ����1����ȫƥ���������� ======
    {
        TestModule::FilterableData data1;

        // ����1: (longArray[0] > 10 OR doubleArray[0] < 0.0)
        data1.longArray[0] = 20;    // > 10�������һ��OR����
        data1.doubleArray[0] = 1.0; // > 0.0������Ӱ�죬��ΪOR������

        // ����2: (matrix2x3[0][0] = 1 OR floatMatrix[1][1] > 0.5)
        data1.matrix2x3[0][0] = 1;  // = 1������ڶ���OR����
        data1.floatMatrix[1][1] = 0.3f; // < 0.5������Ӱ��

        // ����3: (structArray[0].nestedArray[0] > 0 AND structArray[1].nestedArray[1] < 100)
        data1.structArray[0].nestedArray[0] = 50;  // > 0
        data1.structArray[1].nestedArray[1] = 80;  // < 100

        // ���һЩ�����ֶη�ֹδ��ʼ��
        data1.shortField = 1;
        data1.stringField = "data1";
        data1.enumField = TestModule::VALUE_A;

        datas.push_back(data1);
    }

    // ====== ����2��ͨ��OR������·��ƥ�� ======
    {
        TestModule::FilterableData data2;

        // ����1: (longArray[0] > 10 OR doubleArray[0] < 0.0)
        data2.longArray[0] = 5;     // <= 10��������
        data2.doubleArray[0] = -0.5; // < 0.0������OR����һ������

        // ����2: (matrix2x3[0][0] = 1 OR floatMatrix[1][1] > 0.5)
        data2.matrix2x3[0][0] = 0;  // != 1��������
        data2.floatMatrix[1][1] = 0.8f; // > 0.5������OR����һ������

        // ����3: (structArray[0].nestedArray[0] > 0 AND structArray[1].nestedArray[1] < 100)
        data2.structArray[0].nestedArray[0] = 30;  // > 0
        data2.structArray[1].nestedArray[1] = 50;  // < 100

        // ��������ֶ�
        data2.shortField = 2;
        data2.stringField = "data2";
        data2.enumField = TestModule::VALUE_B;

        datas.push_back(data2);
    }

    // ====== ����3���������� - ����1��OR�������� ======
    {
        TestModule::FilterableData data3;

        // ����1: (longArray[0] > 10 OR doubleArray[0] < 0.0)  - ��������
        data3.longArray[0] = 10;    // ����= 10������ >
        data3.doubleArray[0] = 0.0; // ����= 0.0������ <

        // ��ʹ�����������㣬����ANDҲ������
        data3.matrix2x3[0][0] = 1;  // = 1
        data3.floatMatrix[1][1] = 0.8f; // > 0.5
        data3.structArray[0].nestedArray[0] = 1;  // > 0
        data3.structArray[1].nestedArray[1] = 99; // < 100

        // ��������ֶ�
        data3.shortField = 3;
        data3.stringField = "data3_wrong";
        data3.enumField = TestModule::VALUE_C;

        datas.push_back(data3);
    }

    // ====== ����4���������� - ����2��OR�������� ======
    {
        TestModule::FilterableData data4;

        // ����1: (longArray[0] > 10 OR doubleArray[0] < 0.0)
        data4.longArray[0] = 15;    // > 10������

        // ����2: (matrix2x3[0][0] = 1 OR floatMatrix[1][1] > 0.5) - ��������
        data4.matrix2x3[0][0] = 2;  // ���󣺡� 1
        data4.floatMatrix[1][1] = 0.5f; // ����= 0.5������ >

        // ����3��ʹ����Ҳû��
        data4.structArray[0].nestedArray[0] = 1;  // > 0
        data4.structArray[1].nestedArray[1] = 99; // < 100

        // ��������ֶ�
        data4.shortField = 4;
        data4.stringField = "data4_wrong";
        data4.enumField = TestModule::VALUE_D;

        datas.push_back(data4);
    }

    // ====== ����5���������� - ����3��AND�����㣨��һ������ʧ�ܣ� ======
    {
        TestModule::FilterableData data5;

        // ����1: (longArray[0] > 10 OR doubleArray[0] < 0.0)
        data5.longArray[0] = 20;    // > 10������

        // ����2: (matrix2x3[0][0] = 1 OR floatMatrix[1][1] > 0.5)
        data5.matrix2x3[0][0] = 1;  // = 1������

        // ����3: (structArray[0].nestedArray[0] > 0 AND structArray[1].nestedArray[1] < 100)
        data5.structArray[0].nestedArray[0] = 0;  // ����= 0������ > 0
        data5.structArray[1].nestedArray[1] = 50; // < 100����ANDҪ������������

        // ��������ֶ�
        data5.shortField = 5;
        data5.stringField = "data5_wrong";
        data5.enumField = TestModule::VALUE_E;

        datas.push_back(data5);
    }

    // ====== ����6���������� - ����3��AND�����㣨�ڶ�������ʧ�ܣ� ======
    {
        TestModule::FilterableData data6;

        // ����1: (longArray[0] > 10 OR doubleArray[0] < 0.0)
        data6.longArray[0] = 20;    // > 10������

        // ����2: (matrix2x3[0][0] = 1 OR floatMatrix[1][1] > 0.5)
        data6.matrix2x3[0][0] = 1;  // = 1������

        // ����3: (structArray[0].nestedArray[0] > 0 AND structArray[1].nestedArray[1] < 100)
        data6.structArray[0].nestedArray[0] = 10; // > 0������
        data6.structArray[1].nestedArray[1] = 100; // ����= 100������ < 100

        // ��������ֶ�
        data6.shortField = 6;
        data6.stringField = "data6_wrong";
        data6.enumField = TestModule::VALUE_A;

        datas.push_back(data6);
    }

    StatusCondition& sc = dr->get_statuscondition();
    WaitSet ws;
    ws.attach_condition(sc);
    ConditionSeq active_conditions;
    std::thread th_1(
        [&] {
            for (int i = 0; i < 2; i++) {
                EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_OK);

                SequenceData<TestModule::FilterableData> data_seq;
                SampleInfoSeq info_seq;

                EXPECT_EQ(dr->take(
                    data_seq, info_seq, LENGTH_UNLIMITED,
                    ANY_SAMPLE_STATE, ANY_VIEW_STATE, ANY_INSTANCE_STATE),
                    RETCODE_OK);
                EXPECT_TRUE(data_seq[0].longArray[0] > 10 ||
                    data_seq[0].doubleArray[0] < 0.0);
                EXPECT_TRUE(data_seq[0].matrix2x3[0][0] == 1 ||
                    data_seq[0].floatMatrix[1][1] > 0.5f);
                EXPECT_TRUE(data_seq[0].structArray[0].nestedArray[0] > 0 &&
                    data_seq[0].structArray[1].nestedArray[1] < 100);
            }
            EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_TIMEOUT);

        });
    std::thread th_2(
        [&] {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            for (const auto& data : datas) {
                EXPECT_EQ(dw->write(&data, HANDLE_NIL), RETCODE_OK);
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
            }
        });
    th_1.join();
    th_2.join();
    par_w->delete_contained_entities();
    par_r->delete_contained_entities();
    TheParticipantFactory->delete_participant(par_w);
    TheParticipantFactory->delete_participant(par_r);
    
}

TEST(ContentFilteredTopicTest, ContentFilteredTopic_fuctest3) {
    const char* type_name = TestModule::FilterableDataTypeSupport::get_instance()->get_typename();

    DomainParticipant* par_w = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_w->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());

    Topic* top_w = par_w->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    DataWriter* dw = par_w->create_publisher(PUBLISHER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datawriter(top_w, DATAWRITER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);

    DomainParticipant* par_r = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    par_r->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());
    Topic* top_r = par_r->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
    std::string filter_expression = "(shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)\
        AND(longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)\
        AND(charField = 'A' OR byteField = 9)\
        AND(stringField LIKE 'test%' OR fixedStringField = 'fixed')\
        AND(enumField = 'VALUE_A' OR enumField = 'VALUE_B')\
        AND(boolArray[0] = 1 OR boolArray[1] = 0)";
    StringSeq expression_parameters;
    ContentFilteredTopic* cftop = par_r->create_contentfilteredtopic("CFT_ContentFilteredTopic", top_r, filter_expression, expression_parameters);
    DataReader* dr = par_r->create_subscriber(SUBSCRIBER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
        create_datareader(cftop, DATAREADER_QOS_DEFAULT, nullptr, DATA_AVAILABLE_STATUS);

    std::vector<TestModule::FilterableData> datas;

    // ====== ����1����ȫƥ������������ÿ��OR�ĵ�һ�������� ======
    {
        TestModule::FilterableData data1;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data1.shortField = 1;        // = 1

        // ����2: (longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)
        data1.longlongField = 5;     // = 5

        // ����3: (charField = 'A' OR byteField = 9)
        data1.charField = 'A';       // = 'A'

        // ����4: (stringField LIKE 'test%' OR fixedStringField = 'fixed')
        data1.stringField = "testData123";  // ��'test'��ͷ

        // ����5: (enumField = 'VALUE_A' OR enumField = 'VALUE_B')
        data1.enumField = TestModule::VALUE_A;  // = 'VALUE_A'

        // ����6: (boolArray[0] = TRUE OR boolArray[1] = FALSE)
        data1.boolArray[0] = true;   // = TRUE
        data1.boolArray[1] = true;   // ����ֵ��Ӱ��

        datas.push_back(data1);
    }

    // ====== ����2��ͨ��OR������·��ƥ�� ======
    {
        TestModule::FilterableData data2;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data2.shortField = 0;        // �� 1
        data2.ushortField = 2;       // = 2������ڶ���OR����

        // ����2: (longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)
        data2.longlongField = 0;     // �� 5
        data2.ulonglongField = 6;    // = 6������ڶ���OR����

        // ����3: (charField = 'A' OR byteField = 9)
        data2.charField = 'B';       // �� 'A'
        data2.byteField = 9;         // = 9������ڶ���OR����

        // ����4: (stringField LIKE 'test%' OR fixedStringField = 'fixed')
        data2.stringField = "otherData";  // ����'test'��ͷ
        data2.fixedStringField = "fixed"; // = 'fixed'������ڶ���OR����

        // ����5: (enumField = 'VALUE_A' OR enumField = 'VALUE_B')
        data2.enumField = TestModule::VALUE_B;  // = 'VALUE_B'������ڶ���OR����

        // ����6: (boolArray[0] = TRUE OR boolArray[1] = FALSE)
        data2.boolArray[0] = false;  // �� TRUE
        data2.boolArray[1] = false;  // = FALSE������ڶ���OR����

        datas.push_back(data2);
    }

    // ====== ����3�����·��ƥ�� ======
    {
        TestModule::FilterableData data3;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data3.longField = 3;         // = 3�����������OR����

        // ����2: (longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)
        data3.floatField = 7.0f;     // = 7.0�����������OR����

        // ����3: (charField = 'A' OR byteField = 9)
        data3.charField = 'A';       // = 'A'

        // ����4: (stringField LIKE 'test%' OR fixedStringField = 'fixed')
        data3.stringField = "testMixed";  // ��'test'��ͷ

        // ����5: (enumField = 'VALUE_A' OR enumField = 'VALUE_B')
        data3.enumField = TestModule::VALUE_A;  // = 'VALUE_A'

        // ����6: (boolArray[0] = TRUE OR boolArray[1] = FALSE)
        data3.boolArray[0] = true;   // = TRUE

        datas.push_back(data3);
    }

    // ====== ����4�����������������һ��ORѡ�� ======
    {
        TestModule::FilterableData data4;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data4.ulongField = 4;        // = 4���������һ��OR����

        // ����2: (longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)
        data4.doubleField = 8.0;     // = 8.0���������һ��OR����

        // ����3: (charField = 'A' OR byteField = 9)
        data4.byteField = 9;         // = 9���������һ��OR����

        // ����4: (stringField LIKE 'test%' OR fixedStringField = 'fixed')
        data4.fixedStringField = "fixed"; // = 'fixed'���������һ��OR����

        // ����5: (enumField = 'VALUE_A' OR enumField = 'VALUE_B')
        data4.enumField = TestModule::VALUE_B;  // = 'VALUE_B'���������һ��OR����

        // ����6: (boolArray[0] = TRUE OR boolArray[1] = FALSE)
        data4.boolArray[1] = false;  // = FALSE���������һ��OR����

        datas.push_back(data4);
    }

    // ====== ����5���������� - ����1��OR�������� ======
    {
        TestModule::FilterableData data5;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data5.shortField = 10;       // �� 1
        data5.ushortField = 20;      // �� 2
        data5.longField = 30;        // �� 3
        data5.ulongField = 40;       // �� 4

        // ����������ʹȫ�����㣬����ANDҲ������
        data5.longlongField = 5;     // = 5
        data5.charField = 'A';       // = 'A'
        data5.stringField = "testData";
        data5.enumField = TestModule::VALUE_A;
        data5.boolArray[0] = true;   // = TRUE

        datas.push_back(data5);
    }

    // ====== ����6���������� - ����2��OR�������� ======
    {
        TestModule::FilterableData data6;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data6.shortField = 1;        // = 1

        // ����2: (longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)
        data6.longlongField = 10;    // �� 5
        data6.ulonglongField = 20;   // �� 6
        data6.floatField = 10.0f;    // �� 7.0
        data6.doubleField = 20.0;    // �� 8.0

        // ������������Ҳû��
        data6.charField = 'A';
        data6.stringField = "testData";
        data6.enumField = TestModule::VALUE_A;
        data6.boolArray[0] = true;

        datas.push_back(data6);
    }

    // ====== ����7���������� - ����3��OR�������� ======
    {
        TestModule::FilterableData data7;

        // ����1: (shortField = 1 OR ushortField = 2 OR longField = 3 OR ulongField = 4)
        data7.shortField = 1;        // = 1

        // ����2: (longlongField = 5 OR ulonglongField = 6 OR floatField = 7.0 OR doubleField = 8.0)
        data7.longlongField = 5;     // = 5

        // ����3: (charField = 'A' OR byteField = 9)
        data7.charField = 'B';       // �� 'A'
        data7.byteField = 10;        // �� 9

        // ������������Ҳû��
        data7.stringField = "testData";
        data7.enumField = TestModule::VALUE_A;
        data7.boolArray[0] = true;

        datas.push_back(data7);
    }

    // ====== ����8���������� - ����4��OR�������� ======
    {
        TestModule::FilterableData data8;

        // ����1-3����
        data8.shortField = 1;        // = 1
        data8.longlongField = 5;     // = 5
        data8.charField = 'A';       // = 'A'

        // ����4: (stringField LIKE 'test%' OR fixedStringField = 'fixed')
        data8.stringField = "wrongData";    // ����'test'��ͷ
        data8.fixedStringField = "wrong";   // �� 'fixed'

        // ������������Ҳû��
        data8.enumField = TestModule::VALUE_A;
        data8.boolArray[0] = true;

        datas.push_back(data8);
    }

    // ====== ����9���������� - ����5��OR�������� ======
    {
        TestModule::FilterableData data9;

        // ����1-4����
        data9.shortField = 1;        // = 1
        data9.longlongField = 5;     // = 5
        data9.charField = 'A';       // = 'A'
        data9.stringField = "testData"; // ��'test'��ͷ

        // ����5: (enumField = 'VALUE_A' OR enumField = 'VALUE_B')
        data9.enumField = TestModule::VALUE_C;  // �Ȳ���AҲ����B

        // ������������Ҳû��
        data9.boolArray[0] = true;

        datas.push_back(data9);
    }

    // ====== ����10���������� - ����6��OR�������� ======
    {
        TestModule::FilterableData data10;

        // ����1-5����
        data10.shortField = 1;        // = 1
        data10.longlongField = 5;     // = 5
        data10.charField = 'A';       // = 'A'
        data10.stringField = "testData";
        data10.enumField = TestModule::VALUE_A;

        // ����6: (boolArray[0] = TRUE OR boolArray[1] = FALSE)
        data10.boolArray[0] = false;  // �� TRUE
        data10.boolArray[1] = true;   // �� FALSE

        datas.push_back(data10);
    }

    StatusCondition& sc = dr->get_statuscondition();
    WaitSet ws;
    ws.attach_condition(sc);
    ConditionSeq active_conditions;
    std::thread th_1(
        [&] {
            for (int i = 0; i < 4; i++) {
                EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_OK);

                SequenceData<TestModule::FilterableData> data_seq;
                SampleInfoSeq info_seq;

                EXPECT_EQ(dr->take(
                    data_seq, info_seq, LENGTH_UNLIMITED,
                    ANY_SAMPLE_STATE, ANY_VIEW_STATE, ANY_INSTANCE_STATE),
                    RETCODE_OK);

                EXPECT_TRUE(data_seq[0].shortField == 1 ||
                    data_seq[0].ushortField == 2 ||
                    data_seq[0].longField == 3 ||
					data_seq[0].ulongField == 4);
                EXPECT_TRUE(data_seq[0].longlongField == 5 ||
                    data_seq[0].ulonglongField == 6 ||
                    data_seq[0].floatField == 7.0f ||
                    data_seq[0].doubleField == 8.0);
                EXPECT_TRUE(data_seq[0].charField == 'A' ||
                    data_seq[0].byteField == 9);
                EXPECT_TRUE(data_seq[0].stringField.find("test") == 0 ||
                    data_seq[0].fixedStringField == "fixed");
                EXPECT_TRUE(data_seq[0].enumField == TestModule::VALUE_A ||
                    data_seq[0].enumField == TestModule::VALUE_B);
                EXPECT_TRUE(data_seq[0].boolArray[0] == true ||
					data_seq[0].boolArray[1] == false);
            }
            EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_TIMEOUT);
        });
    std::thread th_2(
        [&] {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            for (const auto& data : datas) {
                EXPECT_EQ(dw->write(&data, HANDLE_NIL), RETCODE_OK);
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
            }
        });
    th_1.join();
    th_2.join();
    par_w->delete_contained_entities();
    par_r->delete_contained_entities();
    TheParticipantFactory->delete_participant(par_w);
    TheParticipantFactory->delete_participant(par_r);
 }

 TEST(ContentFilteredTopicTest, ContentFilteredTopic_fuctest4) {
     const char* type_name = TestModule::FilterableDataTypeSupport::get_instance()->get_typename();

     DomainParticipant* par_w = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
     par_w->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());

     Topic* top_w = par_w->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
     DataWriter* dw = par_w->create_publisher(PUBLISHER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
         create_datawriter(top_w, DATAWRITER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);

     DomainParticipant* par_r = TheParticipantFactory->create_participant(0, PARTICIPANT_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
     par_r->registe_type(type_name, TestModule::FilterableDataTypeSupport::get_instance());
     Topic* top_r = par_r->create_topic("ContentFilteredTopic", type_name, TOPIC_QOS_DEFAULT, nullptr, STATUS_MASK_NONE);
     std::string filter_expression = "(shortField >= 10)\
         AND(ushortField <= 20)\
         AND(longField <> 30)\
         AND(doubleField >= 10.5)\
         AND(shortField < longField)\
         AND(floatField >= doubleField)\
         AND('VALUE_B' = enumField)";
     StringSeq expression_parameters;
     ContentFilteredTopic* cftop = par_r->create_contentfilteredtopic("CFT_ContentFilteredTopic", top_r, filter_expression, expression_parameters);
     DataReader* dr = par_r->create_subscriber(SUBSCRIBER_QOS_DEFAULT, nullptr, STATUS_MASK_NONE)->
         create_datareader(cftop, DATAREADER_QOS_DEFAULT, nullptr, DATA_AVAILABLE_STATUS);

     std::vector<TestModule::FilterableData> datas;
     // ====== ����1����ȫƥ���������� ======
     {
         TestModule::FilterableData data1;
         data1.shortField = 15; 
         data1.ushortField = 20;
         data1.longField = 100;
         data1.doubleField = 20.0;
         data1.floatField = 25.0f;
         data1.enumField = TestModule::VALUE_B; 

         datas.push_back(data1);
     }

     // ====== ����2����һ��ƥ������ ======
     {
         TestModule::FilterableData data2;
         data2.shortField = 10;
         data2.ushortField = 0;
         data2.longField = 29;
         data2.doubleField = 10.5;
         data2.floatField = 10.5f;
         data2.enumField = TestModule::VALUE_B;

         datas.push_back(data2);
     }

     // ====== ����3���������� - shortField������ >=10 ======
     {
         TestModule::FilterableData data3;
         data3.shortField = 9;
         data3.ushortField = 20;
         data3.longField = 100;
         data3.doubleField = 20.0;
         data3.floatField = 25.0f;
         data3.enumField = TestModule::VALUE_B;

         datas.push_back(data3);
     }

     // ====== ����4���������� - ushortField������ <=20 ======
     {
         TestModule::FilterableData data4;
         data4.shortField = 15;
         data4.ushortField = 21;

         data4.longField = 100;
         data4.doubleField = 20.0;
         data4.floatField = 25.0f;
         data4.enumField = TestModule::VALUE_B; 

         datas.push_back(data4);
     }

     // ====== ����5���������� - longField������ <>30������30�� ======
     {
         TestModule::FilterableData data5;
         data5.shortField = 15; 
         data5.ushortField = 20;
         data5.longField = 30; 

         data5.doubleField = 20.0; 
         data5.floatField = 25.0f; 
         data5.enumField = TestModule::VALUE_B; 

         datas.push_back(data5);
     }

     // ====== ����6���������� - enumField����VALUE_B ======
     {
         TestModule::FilterableData data6;
         data6.shortField = 15;
         data6.ushortField = 20;
         data6.longField = 100;
         data6.doubleField = 20.0;
         data6.floatField = 25.0f;
         data6.enumField = TestModule::VALUE_A;

         datas.push_back(data6);
     }

     StatusCondition& sc = dr->get_statuscondition();
     WaitSet ws;
     ws.attach_condition(sc);
     ConditionSeq active_conditions;
     std::thread th_1(
         [&] {
             for (int i = 0; i < 2; i++) {
                 EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_OK);

                 SequenceData<TestModule::FilterableData> data_seq;
                 SampleInfoSeq info_seq;

                 EXPECT_EQ(dr->take(
                     data_seq, info_seq, LENGTH_UNLIMITED,
                     ANY_SAMPLE_STATE, ANY_VIEW_STATE, ANY_INSTANCE_STATE),
                     RETCODE_OK);
				 EXPECT_TRUE(data_seq[0].shortField >= 10);
				 EXPECT_TRUE(data_seq[0].ushortField <= 20);
				 EXPECT_TRUE(data_seq[0].longField != 30);
				 EXPECT_TRUE(data_seq[0].doubleField >= 10.5);
				 EXPECT_TRUE(data_seq[0].shortField < data_seq[0].longField);
				 EXPECT_TRUE(data_seq[0].floatField >= data_seq[0].doubleField);
				 EXPECT_EQ(data_seq[0].enumField, TestModule::VALUE_B);

             }
             EXPECT_EQ(ws.wait(active_conditions, { 10,0 }), RETCODE_TIMEOUT);
         });
     std::thread th_2(
         [&] {
             std::this_thread::sleep_for(std::chrono::seconds(1));
             for (const auto& data : datas) {
                 EXPECT_EQ(dw->write(&data, HANDLE_NIL), RETCODE_OK);
                 std::this_thread::sleep_for(std::chrono::milliseconds(500));
             }
         });
     th_1.join();
     th_2.join();
     par_w->delete_contained_entities();
     par_r->delete_contained_entities();
     TheParticipantFactory->delete_participant(par_w);
     TheParticipantFactory->delete_participant(par_r);
}
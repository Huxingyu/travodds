//Copyright(c)[2025][AGIROS][TravoDDS] is licensed under Mulan PSL v2.
//
//You can use this software according to the terms and conditions of
//the Mulan PSL v2.You may obtain a copy of Mulan PSL v2 at :
//http://license.coscl.org.cn/MulanPSL2
//
//THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF
//ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
//
//See the Mulan PSL v2 for more details.
#ifndef TRAVODDS_RTPS_TRANSPORT_SHAREDMEMSOCKET_H
#define TRAVODDS_RTPS_TRANSPORT_SHAREDMEMSOCKET_H

#include <functional>
#include <asio.hpp>
#include "rtps/transport/interprocesstype.h"

TRAVODDS_NAMESPACE_BEGIN

class SharedMemAccept;

/*
 * yuguxu
 * 模拟点对点socket连接
 * 读和写的操作只会分别在两个节点
 * 不存在读或写的操作会发生在两个进程
 */
class SharedMemSocket {
public:
    struct Message_t {
        uint32_t dataSize = 0;
        char data[1];
    };
public:
    SharedMemSocket();
    SharedMemSocket(std::function<void(char*, const uint32_t&)> callback);
    ~SharedMemSocket();

    bool Connect(const std::string& srcport, const std::string& destport);

    bool Connect(const std::string& destport);

    void Write(const char* message, uint32_t len);

    void Shutdown();

    bool IsShutdown() const;

    void Close(bool haslock = false);
private:
    void CleanupResources();

    bool IsWriteSucfully(const char* message, const uint32_t& len);

    void ReadFromSharedMem();

    /* scoket 置NULL 共享资源置NULL */
    void SetNull();

private:
    std::function<void(char*, const uint32_t&)> callback_;
    asio::thread_pool pool_;
    uint32_t port_;
    std::string acceptPort_;
    std::string sharedMemoryName_;
    const char* objectName_ = "TravoddsTransporType";
    // 与共享内存保持一致
    bool shutdown_ = false;

	bool isClosed_ = false;
   
    std::unique_ptr<InterprocessType::managed_shared_memory> segment_;

    struct Data {
        // 读写锁、条件等待集
        InterprocessType::interprocess_mutex rmutex;
        InterprocessType::interprocess_condition rcondition;
        InterprocessType::interprocess_mutex wmutex;
        InterprocessType::interprocess_condition wcondition;

		// 当前读取位置
        std::atomic<uint32_t> readpos;
		// 当前写入位置
        std::atomic<uint32_t> writepos;
        // 读写引用记数
        std::atomic<uint32_t> refs;

        std::atomic<uint32_t> usedBytes;

        bool shutdown = false;
        //缓存实际长度是允许单次写入的两倍
        char msg[SHM_MAX_MESSAGE_SIZE * 2 + 5];
        Data() : readpos(0), writepos(0), refs(0), usedBytes(0), msg{ 0 } {};
    };
    Data* data_;
    size_t buffersize_ = SHM_MAX_MESSAGE_SIZE * 2;
    size_t sharedMemSize_ = 1024 + sizeof(Data);

    friend SharedMemAccept;
};

TRAVODDS_NAMESPACE_END



#endif

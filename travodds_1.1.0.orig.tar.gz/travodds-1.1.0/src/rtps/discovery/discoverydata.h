//Copyright(c)[2025][AGIROS][TravoDDS] is licensed under Mulan PSL v2.
//
//You can use this software according to the terms and conditions of
//the Mulan PSL v2.You may obtain a copy of Mulan PSL v2 at :
//http://license.coscl.org.cn/MulanPSL2
//
//THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF
//ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
//
//See the Mulan PSL v2 for more details.
#ifndef TRAVODDS_RTPS_DISCOVERY_DISCOVERYDATA_H
#define TRAVODDS_RTPS_DISCOVERY_DISCOVERYDATA_H

#include "type/builtintopicdata.h"
#include "rtps/basictypertps.h"

TRAVODDS_NAMESPACE_BEGIN

struct SPDPdiscoveredParticipantData
{
	ParticipantBuiltinTopicData ddsParticipantData;
	/* rtps v2.5 Table 8.78 */
	DomainId_t domainId; /* 接收SPDPdiscoveredParticipantData的本地参与者的domainId */
	std::string domainTag;
	ProtocolVersion_t protocolVersion;
	//GuidPrefix_t guidPrefix;
	VendorId_t vendorId;
	bool expectsInlineQos;
	LocatorSeq metatrafficUnicastLocatorList;
	LocatorSeq metatrafficMulticastLocatorList;
	LocatorSeq defaultUnicastLocatorList;
	LocatorSeq defaultMulticastLocatorList;
	BuiltinEndpointSet_t availableBuiltinEndpoints;
	BuiltinEndpointQos_t builtinEndpointQos;
	Count_t manualLivelinessCount;

	Duration_t leaseDuration;

	SPDPdiscoveredParticipantData () : domainId(0), protocolVersion(PROTOCOLVERSION), vendorId(VENDORID_PROSIMA), expectsInlineQos(false), availableBuiltinEndpoints(0), builtinEndpointQos(0), manualLivelinessCount(0), leaseDuration(TIME_ZERO) {
	}
};

using SpdpDataMap = std::map<BuiltinTopicKey_t, SPDPdiscoveredParticipantData>;

struct DiscoveredWriterData
{
#ifdef DDSSECURITY
	PublicationBuiltinTopicSecureData ddsPublicationData;
#else
	PublicationBuiltinTopicData ddsPublicationData;
#endif //DDSSECURITY
	GUID_t remoteWriterGuid;
	/* rtps v2.5 Figure 8.30 */
	GUID_t remoteGroupGuid;
	LocatorSeq unicastLocatorList;
	LocatorSeq multicastLocatorList;
	int32_t dataMaxSizeSerialized;
	DiscoveredWriterData() : dataMaxSizeSerialized(0) {}
};

struct DiscoveredReaderData
{
#ifdef DDSSECURITY
	SubscriptionBuiltinTopicSecureData ddsSubscriptionData;
#else
	SubscriptionBuiltinTopicData ddsSubscriptionData;
#endif //DDSSECURITY
	/* rtps v2.5 Figure 8.30 */
	GUID_t remoteReaderGuid;
	GUID_t remoteGroupGuid;
	LocatorSeq unicastLocatorList;
	LocatorSeq multicastLocatorList;
	ContentFilterProperty_t contentFilter;
};

#ifdef DDSSECURITY

typedef DiscoveredReaderData DiscoveredReaderSecureData;
typedef DiscoveredWriterData DiscoveredWriterSecureData;

#endif // DDSSECURITY

struct DiscoveredTopicData
{
	TopicBuiltinTopicData ddsTopicData;
};

TRAVODDS_NAMESPACE_END

#endif // !TRAVODDS_RTPS_DISCOVERY_DISCOVERYDATA_H

// Copyright (c) 2017-2020 Dr. Colin Hirsch and Daniel Frey
// Please see LICENSE for license or visit https://github.com/taocpp/PEGTL/

#ifndef TAO_PEGTL_VERSION_HPP
#define TAO_PEGTL_VERSION_HPP

#define TAO_PEGTL_VERSION "2.8.3"

#define TAO_PEGTL_VERSION_MAJOR 2
#define TAO_PEGTL_VERSION_MINOR 8
#define TAO_PEGTL_VERSION_PATCH 3

// Compatibility, remove with 3.0.0
#define TAOCPP_PEGTL_VERSION TAO_PEGTL_VERSION
#define TAOCPP_PEGTL_VERSION_MAJOR TAO_PEGTL_VERSION_MAJOR
#define TAOCPP_PEGTL_VERSION_MINOR TAO_PEGTL_VERSION_MINOR
#define TAOCPP_PEGTL_VERSION_PATCH TAO_PEGTL_VERSION_PATCH

#endif

//Copyright(c)[2025][AGIROS][TravoDDS] is licensed under Mulan PSL v2.
//
//You can use this software according to the terms and conditions of
//the Mulan PSL v2.You may obtain a copy of Mulan PSL v2 at :
//http://license.coscl.org.cn/MulanPSL2
//
//THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF
//ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
//
//See the Mulan PSL v2 for more details.
#ifndef AGIDDS_DCPS_LISTENER_PUBLISHERLISTENER_H
#define AGIDDS_DCPS_LISTENER_PUBLISHERLISTENER_H

#include "dcps/listener/datawriterlistener.h"

AGIDDS_NAMESPACE_BEGIN
/**
 * @brief 类PublisherListener，允许最终用户实现由某些事件触发的回调。
 * 它继承所有DataWriterListener回调。
 */
class PublisherListener : public DataWriterListener {

};

AGIDDS_NAMESPACE_END
#endif // !AGIDDS_DCPS_LISTENER_PUBLISHERLISTENER_H

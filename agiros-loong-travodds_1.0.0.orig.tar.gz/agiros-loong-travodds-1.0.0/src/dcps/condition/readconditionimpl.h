//Copyright(c)[2025][AGIROS][TravoDDS] is licensed under Mulan PSL v2.
//
//You can use this software according to the terms and conditions of
//the Mulan PSL v2.You may obtain a copy of Mulan PSL v2 at :
//http://license.coscl.org.cn/MulanPSL2
//
//THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF
//ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
//
//See the Mulan PSL v2 for more details.
#ifndef AGIDDS_DCPS_CONDITION_READCONDITIONIMPL_H
#define AGIDDS_DCPS_CONDITION_READCONDITIONIMPL_H

#include "dcps/condition/readcondition.h"
#include "dcps/condition/conditionimpl.h"
#include "dcps/subscribe/states.h"

AGIDDS_NAMESPACE_BEGIN

class DataReaderImpl;
class ReadConditionImpl : public virtual ReadCondition, public ConditionImpl {
public:
	ReadConditionImpl(SampleStateMask smaple_states, ViewStateMask view_states, InstanceStateMask instance_states, DataReaderImpl* dataReader);

    ~ReadConditionImpl();

	virtual bool get_trigger_value() const;

	DataReader* get_datareader() const;

	const SampleStateMask& get_sample_state_mask() const;

	const ViewStateMask& get_view_state_mask() const;

	const InstanceStateMask& get_instance_state_mask() const;
private:
    SampleStateMask sampleStateMask_;
    ViewStateMask viewStateMask_;
    InstanceStateMask instanceStateMask_;
    DataReaderImpl* dataReader_ = nullptr;
};

AGIDDS_NAMESPACE_END
#endif // !AGIDDS_DCPS_CONDITION_READCONDITIONIMPL_H

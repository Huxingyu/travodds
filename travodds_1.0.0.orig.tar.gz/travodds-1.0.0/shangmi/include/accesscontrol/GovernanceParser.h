//Copyright(c)[2025][AGIROS][TravoDDS] is licensed under Mulan PSL v2.
//
//You can use this software according to the terms and conditions of
//the Mulan PSL v2.You may obtain a copy of Mulan PSL v2 at :
//http://license.coscl.org.cn/MulanPSL2
//
//THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF
//ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
//
//See the Mulan PSL v2 for more details.
#ifndef __SECURITY_ACCESSCONTROL_GOVERNANCEPARSER_H__
#define __SECURITY_ACCESSCONTROL_GOVERNANCEPARSER_H__

#include <string>
#include <tinyxml2.h>
#include "accesscontrol/PermissionsTypes.h"

TRAVODDS_NAMESPACE_BEGIN

enum class ProtectionKind
{
    NONE,
    SIGN,
    ENCRYPT,
    SIGN_WITH_ORIGIN_AUTHENTICATION,
    ENCRYPT_WITH_ORIGIN_AUTHENTICATION
};

struct TopicRule
{
    std::string topic_expression;
    bool enable_discovery_protection;
    bool enable_liveliness_protection;
    bool enable_read_access_control;
    bool enable_write_access_control;
    ProtectionKind metadata_protection_kind;
    ProtectionKind data_protection_kind;
};

struct DomainRule
{
    Domains domains;
    bool allow_unauthenticated_participants;
    bool enable_join_access_control;
    ProtectionKind discovery_protection_kind;
    ProtectionKind liveliness_protection_kind;
    ProtectionKind rtps_protection_kind;
    std::vector<TopicRule> topic_rules;
};

struct DomainAccessRules
{
    std::vector<DomainRule> rules;
};

class GovernanceParser
{
public:

    bool parse_stream(
            const char* stream,
            size_t stream_length);

    void swap(
            DomainAccessRules& rules);

private:

    bool parse_domain_access_rules_node(
            tinyxml2::XMLElement* root);

    bool parse_domain_access_rules(
            tinyxml2::XMLElement* root);

    bool parse_domain_rule(
            tinyxml2::XMLElement* root,
            DomainRule& rule);

    bool parse_topic_access_rules(
            tinyxml2::XMLElement* root,
            std::vector<TopicRule>& rules);

    bool parse_topic_rule(
            tinyxml2::XMLElement* root,
            TopicRule& rule);

    DomainAccessRules access_rules_;
};

TRAVODDS_NAMESPACE_END
#endif // __SECURITY_ACCESSCONTROL_GOVERNANCEPARSER_H__